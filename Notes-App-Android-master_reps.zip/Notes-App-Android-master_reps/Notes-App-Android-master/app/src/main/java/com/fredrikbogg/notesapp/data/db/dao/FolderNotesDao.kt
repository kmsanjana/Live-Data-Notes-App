package com.fredrikbogg.notesapp.data.db.dao

import androidx.room.Dao

@Dao
interface FolderNotesDao : NotesDao, FoldersDao